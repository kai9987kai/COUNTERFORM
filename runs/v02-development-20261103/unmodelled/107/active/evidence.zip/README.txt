COUNTERFORM synthetic evidence. Verify: python -m counterform verify bundle.zip
Replay: python -m counterform replay receipt.json
CAD is conceptual; STL units are millimetres. No physical guarantee.
